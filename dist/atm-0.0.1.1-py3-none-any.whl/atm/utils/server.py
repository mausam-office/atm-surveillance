import logging
import requests


class Server:
    def __init__(self, configs) -> None:
        self.configs = configs
        self.initilize()

    def initilize(self):
        self.baseurl = self.configs.get('base_url')
        self.route_atm_alert = self.configs.get('route_atm_alert')

        self.atm_alert_url = self.construct_url(self.baseurl, self.route_atm_alert)

    def construct_url(self, base_url: str, route: str):
        return base_url + route \
            if base_url.endswith('/') or route.startswith('/') else base_url + '/' + route
        
    def alert(self, **kwargs):
        try:
            requests.post(
                self.atm_alert_url, 
                data=kwargs.get('data', {'title':'', 'image':''}),
                timeout=0.5
            )
            logging.info("Successfully alerted.")
        except Exception as e:
            logging.error(f"Can't alert due to: {str(e)}")
