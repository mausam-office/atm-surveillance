import atexit
import base64
import cv2
import logging
import os
import platform
import signal
import subprocess
import sys
import threading
import time
import warnings

import numpy as np

from datetime import datetime
from multiprocessing import Queue

from atm.callbacks.image_storage import SetImageCallback
from atm.callbacks.result_storage import SetResultCallback
from atm.model.pipelines.prediction_pipeline import prediction_pipeline
from atm.utils.server import Server
from atm.utils import checks
from atm.utils.features import COLUMNS 
from atm.utils.fresh_frame import FreshestFrame
from atm.utils.load_file import read_yaml_file
from atm.utils.pose_detection import Detection
from atm.utils.postprocess import Postprocess
from atm.utils.save_dataset import CSVDataset
from atm.utils.disk_storage import get_available_memory

warnings.warn = lambda *args, **kwargs: None

TF_ENABLE_ONEDNN_OPTS=0
DEFAULT_OUT_VIDEODIR = 'media/recordings'
DEFAULT_MODELDIR = 'saved_model'
DEFAULT_FOURCC = 'MJPG'
DEFAULT_EXT = 'avi'
DEFAULT_STORAGE_THRESHOLD = 10

GPIO_LED = 23
GPIO_BUTTON = 16

if platform.system() == 'Linux':
    from gpiozero import LED
    import RPi.GPIO as GPIO

    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(GPIO_BUTTON, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    led = LED(GPIO_LED)

q = Queue()
image_callback = SetImageCallback()
ploted_image_callback = SetImageCallback()
result_callback =  SetResultCallback(q)

@atexit.register
def on_exit():
    logging.log(logging.INFO, 'Quiting Application.')

    try:
        if platform.system() == 'Linux':
            led.on()
        process = subprocess.Popen(["sleep", "5"])
        time.sleep(2)
        # Send SIGINT signal to the subprocess (equivalent to pressing Ctrl+C)
        process.send_signal(signal.SIGINT)
        # Wait for the process to terminate and get the return code
        return_code = process.wait()
        if platform.system() == 'Linux':
            led.off()
    except Exception as e:
        logging.warning(f"Exception while quiting {str(e)}")

def validate_update_configs(script_configs, ROOT):
    status = []
    if ((video_parent_dir:=script_configs.get('video_parent_dir')) is None or 
        not isinstance(video_parent_dir, str) or not video_parent_dir):

        out_videodir = os.path.join(ROOT, DEFAULT_OUT_VIDEODIR)
        script_configs['video_parent_dir'] = out_videodir
        logging.log(logging.INFO, f'Using default video saving directory: {out_videodir}')
    else:
        out_videodir = os.path.join(ROOT, script_configs.get('video_parent_dir'))
        script_configs['video_parent_dir'] = out_videodir


    if script_configs.get('fourcc') is None:
        logging.log(logging.INFO, f'Using default fourcc: {DEFAULT_FOURCC}')
        script_configs['fourcc'] = DEFAULT_FOURCC
    
    if script_configs.get('base_url') is None:
        logging.log(logging.INFO, f'Base url not provided')
        status.append(False)

    if script_configs.get('video_file_extention') is None:
        logging.log(logging.INFO, f'Using default video file extension: {DEFAULT_EXT}')
        script_configs['video_file_extention'] = DEFAULT_EXT

    # if script_configs.get('storage_drive') is None:
    #     logging.log(logging.INFO, f'Using default storage: {DEFAULT_STORAGE}')
    #     script_configs['storage_drive'] = DEFAULT_STORAGE
    
    if script_configs.get('free_storge_threshold') is None:
        logging.log(logging.INFO, f'Using default storage threshold: {DEFAULT_STORAGE_THRESHOLD}')
        script_configs['free_storge_threshold'] = DEFAULT_STORAGE_THRESHOLD

    if ((model_dir:=script_configs.get('model_dir')) is None or 
        not isinstance(model_dir, str) or not model_dir):

        script_configs['model_dir'] = DEFAULT_MODELDIR

    model_name = name if (name:=script_configs.get('model_name', '')).endswith('.pkl') else name + '.pkl'
    script_configs['model_path'] = os.path.join(ROOT, DEFAULT_MODELDIR, model_name)

    script_configs['model_path'] =  os.path.join(ROOT, script_configs.get('model_dir'), model_name)

    checks.check_dir_existance([
        'data',
        script_configs.get('video_parent_dir')
    ])
    
    sts = checks.check_file_exitstance(
        script_configs.get('model_path'),
        req_sts=True
    )
    status.append(sts)

    sts = checks.check_videowriter(
        fourcc=script_configs.get('fourcc', 'MJPG'),
        extention=script_configs.get('video_file_extention', 'avi')
    )
    status.append(sts)

    sts = checks.check_landmark_model_name(
        script_configs.get('landmark_model')
    )
    status.append(sts)

    sts = checks.check_base_url(script_configs.get('base_url'))
    status.append(sts)

    routes = list(set(map(lambda key: script_configs[key] if key.startswith('route') else '', script_configs.keys())))
    routes.remove('')

    assert len(routes) > 0, logging.error("Must have at least one route")

    sts = checks.check_routes(routes)
    status.append(sts)

    return all(status), script_configs

def register_video_source(video_source):
    if video_source.startswith('rtsp://'):
        cam = FreshestFrame(camera=video_source, callback=image_callback.set_image)
    else:
        cam = cv2.VideoCapture(video_source)
    return cam


class PostProcessThread(threading.Thread):
    def __init__(self, result_q, configs, ploted_image_callback, fps, img_wh):
        self.result_q = result_q
        self.configs = configs
        self.ploted_image_callback = ploted_image_callback
        self.csv_dataset = CSVDataset('./data/dataset_pred.csv', COLUMNS)
        self.pp = Postprocess(q, self.csv_dataset, configs)
        self.fourcc = cv2.VideoWriter_fourcc(*self.configs.get('fourcc', 'MJPG')) # mp4v -> mp4, MJPG-> avi
        self.out = None
        self.fps = fps
        self.img_wh = img_wh
        self.set_yesterday()
        self.update_out(init=True)
        unit_factor = 60*60 if self.configs.get('duration_unit') == 'hour' else 60 
        self.duration_threshold = self.configs.get('video_duration') * unit_factor

        self.server = Server(self.configs)
        
        self.cont_safe_occurence = 0
        self.safe_occurence_threshold = self.configs.get('safe_occurence_threshold', 4)
        self.cont_unsafe_occurence = 0
        self.unsafe_occurence_threshold = self.configs.get('unsafe_occurence_threshold', 4)

        self.alerted = False

        super().__init__()
        self.start()

    def start(self):
        self.running = True
        super().start()

    def release(self):
        self.running = False
        time.sleep(0.1)
        if isinstance(self.out, cv2.VideoWriter) and self.out.isOpened():
            self.out.release()
        super().join()

    def run(self):
        while self.running:
            if self.result_q.qsize():
                try:
                    result, image = self.result_q.get()
                    unparsed_data = self.call_postprocess(image, result)

                    df = self.parse(unparsed_data)
                    if df is None:
                        continue

                    predicted_pose = self.pose_classify(df)
                    image = self.overlay(image, predicted_pose)
                    self.check_unsafe_occurence(predicted_pose, image) 
                    self.ploted_image_callback.image = image
                
                    if isinstance(self.out, cv2.VideoWriter) and \
                        get_available_memory(self.configs['video_parent_dir']) > self.configs['free_storge_threshold']\
                        and isinstance(image, np.ndarray):
                        self.out.write(image)
                    
                    image = None
                
                except Exception as e:
                    logging.log(logging.WARNING, f"{str(e)}")
            
            self.check_interval()
            
            time.sleep(0.000001)
    
    def check_unsafe_occurence(self, predicted_pose, image: str):
        if predicted_pose=='safe':
            self.cont_safe_occurence += 1
            if self.cont_safe_occurence > self.safe_occurence_threshold:
                self.cont_unsafe_occurence = 0
                self.alerted = False
        else:
            self.cont_unsafe_occurence += 1
            if self.cont_unsafe_occurence > self.unsafe_occurence_threshold and not self.alerted:
                # alert
                image = self.image2base64(image)
                self.server.alert(data={'title':predicted_pose, 'image':image})
                self.alerted = True
                self.cont_safe_occurence = 0
        
    def call_postprocess(self, image, result):
        data = self.pp.process(
            image, 
            result, 
            angle_calc_lm_idx_list=[
                # points must be in descenting fashion and point2 is central or vertex point
                # point1, point2, point3
                (16, 14, 12), 
                (15, 13, 11),

                (14, 12, 24),
                (13, 11, 23),

                (26, 24, 12),
                (25, 23, 11),

                (28, 26, 24),
                (27, 25, 23),
            ],
            dist_calc_lm_idx_list=[
                # point1, point2, name connecting keypoints with side
                (14, 12, 'width_elbow_shoulder_r'),
                (13, 11, 'width_elbow_shoulder_l'),

                # ((7, 8), (27, 28), 'dist_height_avg'),
                (8, 28, 'dist_height_r'),
                (7, 27, 'dist_height_l'),
                (13, 14, 'dist_width'),

                (12, 24, 'height_shoulder_waist_r'),
                (11, 23, 'height_shoulder_waist_l'),

                (24, 26, 'height_waist_knee_r'),
                (23, 25, 'height_waist_knee_l'),

                (12, 26, 'height_knee_shoulder_r'),
                (11, 25, 'height_knee_shoulder_l'),

                (24, 28, 'height_ankle_waist_r'),
                (23, 27, 'height_ankle_waist_l'),

                (11, 12, "shoulder_l_r"),
                (23, 24, "waist_l_r"),
                (25, 26, "knee_l_r"),
            ],
            actions=[],
            label=None,
            unique_indices=[7, 8, 11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28],
            plotted_img_callaback = None,
            parse=False
        )
        return data

    def parse(self, unparsed_data):
        if unparsed_data is None and not isinstance(unparsed_data, (tuple, list)):
            logging.log(logging.WARNING, 'Either no data to parse or data is not iterable.')
            return
        return self.csv_dataset.parse(*unparsed_data, label='', req_ret=True)
    
    def pose_classify(self, df):
        return prediction_pipeline(df, model_path=self.configs['model_path'])
        
    def overlay(self, image, predicted_pose=None):
        return cv2.putText(
            image,
            text = f'Pose detected: {predicted_pose}',
            org=(20,75),
            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
            fontScale=1,
            thickness=2,
            color=(255,0,0),
            lineType=cv2.LINE_AA
        )

    def set_out(self, out_videopath):
        # self.out = cv2.VideoWriter(out_videopath, self.fourcc, self.fps, (1280, 720)) 
        self.out = cv2.VideoWriter(out_videopath, self.fourcc, self.fps, self.img_wh) 
        if not self.out.isOpened():
            logging.log(logging.ERROR, "Out is set but not opened")
            # self.update_out()
            
        self.set_yesterday()

    def update_out(self, init=False):
        if not init and isinstance(self.out, cv2.VideoWriter) and self.out.isOpened():
            self.out.release()
        out_videopath = self.get_filepath()
        
        self.set_out(out_videopath)
        
    def get_filepath(self):
        today = self.get_today()
        suffix = 0
        while True:
            out_videopath = f"{self.configs['video_parent_dir']}/{str(today).replace(':', '-')}-{suffix}.{self.configs.get('video_file_extention', DEFAULT_EXT)}"
            suffix += 1
            if not os.path.exists(out_videopath):
                logging.log(logging.INFO, f"Saving video to file {out_videopath}")
                break
        return out_videopath
    
    def get_today(self):
        return datetime.now()#.date()
    
    def set_yesterday(self):
        self.yesterday =  self.get_today()
        
    def check_interval(self):
        interval = self.get_today() - self.yesterday
        if interval.seconds > self.duration_threshold and \
            get_available_memory(self.configs['video_parent_dir']) > self.configs['free_storge_threshold']:
            self.update_out()

    def image2base64(self, image):
        # ! Fast
        jpg_img = cv2.imencode('.jpg', image)
        img_str = base64.b64encode(jpg_img[1]).decode('utf-8')
        
        # ! SLOW
        # im = Image.fromarray(image.astype("uint8"))
        # self.rawBytes = io.BytesIO()
        # im.save(self.rawBytes, "png")
        # self.rawBytes.seek(0) 
        # img_str = base64.b64encode(self.rawBytes.read()).decode('utf-8')
        return img_str


def main(config_filepath, ROOT):
    logging.log(logging.INFO, "Application started.")
    script_configs = read_yaml_file(config_filepath)

    status, script_configs = validate_update_configs(script_configs, ROOT)
    if not status:
        logging.log(logging.ERROR, "Configurations not validated.")
        sys.exit()

    cam = register_video_source(script_configs['video_source'])
    detect = Detection(result_callback.set_result, script_configs.get('landmark_model', 'full'))

    if isinstance(cam, FreshestFrame):
        img_w, img_h = cam.img_w, cam.img_h
    elif isinstance(cam, cv2.VideoCapture):
        img_w = cam.get(cv2.CAP_PROP_FRAME_WIDTH)
        img_h = cam.get(cv2.CAP_PROP_FRAME_HEIGHT)
    else:
        sys.exit()

    postprocess = PostProcessThread(q, script_configs, ploted_image_callback, script_configs.get('fps', 15), (int(img_w), int(img_h)))
    # total_iter = 0
    # total_fps = 0
    try:
        while GPIO.input(16) == GPIO.HIGH if platform.system() == 'Linux' else True:
            # start = time.time()
            if not isinstance(cam, FreshestFrame):
                ret, image_callback.image = cam.read()
                if not ret:
                    logging.log(logging.ERROR, "Can't read frame using VideoCapture. Exiting...")
                    break
            if image_callback.image is None:
                continue
            detect(image_callback.image)

            if script_configs.get('show_frames', False) and ploted_image_callback.image is not None:
                cv2.imshow('frame', ploted_image_callback.image)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            # print(f"FPS: {(fps := 1/(time.time() - start))}", end='\r')
            # total_fps += fps
            # total_iter += 1
    except Exception as e:
        logging.error(f"{str(e)}")
    
    # print(f"Avg FPS: {total_fps/total_iter}")
    
    cam.release()
    if script_configs.get('show_frames', False) and ploted_image_callback.image is not None:
        cv2.destroyAllWindows()
    postprocess.release()