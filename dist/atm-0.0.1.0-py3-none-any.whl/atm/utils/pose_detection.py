from typing import Any
from atm.utils import DetectionConfigs


class Detection:
    def __init__(self, callback_func, model_complexity) -> None:
        self.callback_func = callback_func
        available_models_mapping = {'lite': 0, 'full': 1, 'heavy':2}
        self.pose = DetectionConfigs.MP_POSE.Pose(
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5, 
            model_complexity=available_models_mapping[model_complexity]
        )

    def __call__(self, image) -> Any:
        # image.flags.writeable = False
        results = self.pose.process(image)
        # image.flags.writeable = True
        self.callback_func(results, image)
