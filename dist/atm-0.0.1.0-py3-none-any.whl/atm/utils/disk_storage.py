import shutil


def get_available_memory(drive="D:/"):
    total, used, free = shutil.disk_usage(drive)

    free_gb = free / (2**30)
    return free_gb
