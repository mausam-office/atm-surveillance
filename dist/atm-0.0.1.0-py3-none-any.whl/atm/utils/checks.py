import glob
import logging
import os
from pathlib import Path
from typing import Sequence

from atm.utils import ROOT

VALID_VIDEOWRITER_FOURCC_EXT = [('MJPG', 'avi'), ('mp4v', 'mp4')]
VALID_LANDMARK_MODEL_NAMES = ['lite', 'full', 'heavy']

def check_suffix(file, suffix):
    if all([file, suffix]):
        if isinstance(file, str):
            suffix = (suffix,)
        for f in file if isinstance(file, (list, tuple)) else [file]:
            s = Path(f).suffix.lower().strip()
            if s:
                assert s in suffix, f"Acceptable suffix is {suffix}, not {s}"        


def check_file(file: str, suffix: str | list[str] | tuple[str]):
    check_suffix(file, suffix)
    file = file.strip()

    files = glob.glob(str(ROOT / "**" / file), recursive=True) or glob.glob(str(ROOT.parent / file))    # search and find file
    if not files:
        raise FileNotFoundError(f"{file} doesn't exists.")
    elif len(files) > 1:
        raise FileNotFoundError(f"Multiple files match '{file}', specify exact path: {files}")
    
    return files[0] if len(files) else []  # return file


def check_yaml(file, suffix=('yaml', 'yml')):
    return check_file(file, suffix)

def check_dir_existance(dirs):
    if isinstance(dirs, str):
        dirs = [dirs]
    for idx, dir in enumerate(dirs):
        try:
            os.makedirs(dir, exist_ok=True)
        except Exception as e:
            logging.log(logging.ERROR, f'Error of Directory number {idx+1}:{dir}')

def check_file_exitstance(files, req_sts=False) -> bool | None:
    if isinstance(files, str):
        files = [files]
    exists = True
    for file in files:
        if not os.path.exists(file):
            logging.log(logging.ERROR, f"file {file} doesn't exists.")
            exists = False
            break
    if req_sts:
        return exists

def check_videowriter(*, fourcc, extention):
    return (fourcc, extention) in VALID_VIDEOWRITER_FOURCC_EXT

def check_landmark_model_name(name):
    return name in VALID_LANDMARK_MODEL_NAMES

def check_base_url(url: str):
    if isinstance(url, str) and url.startswith(('http://', 'https://')):
        return True
    logging.log(logging.ERROR, f"{url=} is neither string type nor starts with `http://` or `https://`")
    return False

def check_routes(routes: str|Sequence[str]):
    if isinstance(routes, str):
        routes = [routes]
    invalid_routes = []
    for route in routes:
        if not isinstance(route, str) and not route.startswith("atm/public/api"):
            logging.log(logging.ERROR, f"{route=} is neither string type nor starts with `atm/public/api`")
            invalid_routes.append(route)

    return len(invalid_routes) == 0
