import yaml

def read_yaml_file(filepath):
    script_configs = None
    try:
        with open(filepath, 'r') as file:
            script_configs = yaml.safe_load(file)
    except Exception as e:
        print(f"Exception: {e}")
    return script_configs if isinstance(script_configs, dict) else {}
