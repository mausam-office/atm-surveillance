
class SetImageCallback:
    def __init__(self) -> None:
        self.image = None

    def set_image(self, image):
        self.image = image