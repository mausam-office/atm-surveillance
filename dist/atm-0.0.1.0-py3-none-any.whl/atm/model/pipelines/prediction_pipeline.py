import os
import time
import joblib

from functools import lru_cache
from atm.model.components.clean_data import clean_data

@lru_cache
def load_model(model_path):
    # model_path = os.path.join('atm/saved_model' , model_name + '.pkl')
    return joblib.load(open(model_path,'rb'))

def prediction_pipeline(df, model_path):
    X_input, *_ = clean_data(df, False, True)

    model = load_model(model_path)

    model_prediction = model.predict(X_input)
    if (model_prediction == 0 ):
        result = 'unsafe' # 'sitted'
    else:
        result = 'safe' # 'standing'

    return result

